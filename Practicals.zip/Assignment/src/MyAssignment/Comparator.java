package MyAssignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class PriceComparator implements Comparator<Pen>
{

	public int compare(Pen o1, Pen o2)
	{
		// TODO Auto-generated method stub
		if(o1.getPrice()==o2.getPrice())
		return 0;
		else if(o1.getPrice()>=o2.getPrice())
			return 1;
		else return -1;
	}
	 
}
class BrandComparator implements Comparator<Pen>
{
	@Override
	public int compare(Pen o1, Pen o2)
	{
		// TODO Auto-generated method stub
		
		return o1.getBrand().compareTo(o2.getBrand());
	}
	 
}
class Pen implements Comparable<Pen>
{	
	private String brand;
	private double price;
	public Pen(int price,String brand) 
	{
		 this.price=price;
		 this.brand=brand;
	}
	public String toString()
	{
		return "Brand=" + brand + ", Price=" + price +"\n";
	}
	public double getPrice() 
	{
		return price;
	}
	public void setPrice(double price) 
	{
		this.price = price;
	}
	public String getBrand() 
	{
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	@Override
	public int compareTo(Pen o) {
		// TODO Auto-generated method stub
		//if(this.price>o.price)
			//return 1;
		//else if(this.price==o.price)
			//return 0;
		//else return -1;
		return this.brand.compareTo(o.brand);
	}
	 
}
public class Comparator
{	public static void main(String[] args) 
	{
		Pen a=new Pen(2000,"Parker");
		Pen b=new Pen(2009,"Hero");
		Pen c=new Pen(1999,"Trimax");
		List<Pen> x=new ArrayList<Pen>();
		x.add(a);
		x.add(b);
		x.add(c);
		Collections.sort(x,new BrandComparator());//use brand comparator to sort using brands and price using price comparator.
		System.out.println(x);
   }
}

