package MyAssignment;
class b
	{
		float bz;
		int cz;
		double dz;
		void input(String x)
		{
			float b=Float.parseFloat(x);
			int c=Integer.parseInt(x);
			double d=Double.parseDouble(x);
			bz=b;
			cz=c;
			dz=d;
		}
		void disp()
		{
			System.out.println("Float:"+bz);
			System.out.println("Integer:"+cz);
			System.out.println("Double:"+dz);
			
		}
	}
	class Wrapper
	{
		public static void main(String[] args)
		{
		b e=new b();
		e.input("30");
		e.disp();
		}
	}

