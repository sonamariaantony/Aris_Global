package MyAssignment;

 abstract class a
	{
	  public abstract void animalSound();
	  public void sleep()
	  {
	    System.out.println("Zzz");
	  }
	}
	class Pig extends a{
	  public void animalSound() {
	    // The body of animalSound() is provided here
	    System.out.println("The pig says: wee wee");
	  }
	}

	class AbstractionDemo {
	  public static void main(String[] args) {
	    Pig myPig = new Pig(); // Create a Pig object
	    myPig.animalSound();
	    myPig.sleep();
	  }
	}


