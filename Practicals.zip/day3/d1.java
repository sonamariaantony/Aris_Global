package day3;
import java.sql.*;
	import com.mysql.*;
	public class d1 { public static void main(String[] args) {
	// TODO Auto-generated method stub try
	try{
	Class.forName("com.mysql.jdbc.Driver");
	String connectionString="jdbc:mysql://localhost:3306/demo?characterEncoding=utf8";
	String userName="root";
	String password="root";
	java.sql.Connection con=java.sql.DriverManager.getConnection(connectionString,userName,password);
	if(con!=null)
	{
	System.out.println("connected");
	Statement stmt =con.createStatement();
	String query="select * from employee";
	ResultSet rs=stmt.executeQuery(query);
	while(rs.next())
	{
	System.out.println("id " +rs.getInt(1));
	System.out.println("name "+rs.getString(2));
	System.out.println("salary "+rs.getInt(3));
	}
	con.close();
	}
	else
	{
	System.out.println("Not connected");
	}
	}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	}}

	
	
	
	
	
	import java.sql.*;
	import com.mysql.*;

	public class MyJDBC {

	 public static void main(String[] args) {
	// TODO Auto-generated method stub

	 try
	{
	Class.forName("com.mysql.jdbc.Driver");
	String connectionString="jdbc:mysql://localhost:3306/demo?characterEncoding=utf8";
	String userName="root";
	String password="root";
	java.sql.Connection con=java.sql.DriverManager.getConnection(connectionString,userName,password);
	if(con!=null)
	{
	System.out.println("connected");
	Statement stmt =con.createStatement();
	String query="select * from employee";
	ResultSet rs=stmt.executeQuery(query);
	while(rs.next())
	{
	System.out.println("id " +rs.getInt(1));
	System.out.println("name "+rs.getString(2));
	System.out.println("salary "+rs.getInt(3));
	}

	con.close();
	}
	else
	{
	System.out.println("Not connected");
	}
	}
	catch(Exception e)
	{
	e.printStackTrace();
	}
	}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
