package com;
class android{
	
	void email()
	{
		System.out.println("write an email");
	}
}
class nokia extends android{
	void makeacall() {
		System.out.println("make a call");
	}
}
class sumsung extends android{
	void takeapicture()
	{
		System.out.println("takes a picture");}
}
class sony extends android{
	void type()
	{
		System.out.println("can type");}
}

public class inheritance {

	public static void main(String[] args) {
		sony s=new sony();
		sumsung su=new sumsung();
		nokia n=new nokia();
		s.type();
		s.email();
		su.email();
		su.takeapicture();
		n.email();
		n.makeacall();
		}}
