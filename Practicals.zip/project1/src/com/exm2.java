package com;

public class exm2 {

	public static void main(String[] args) {
		char ch='b';
		switch(ch)
		{
		case 'a':
			System.out.println("vowels");
			break;
		case 'e':
			System.out.println("vowels");
			break;
		case 'i':
			System.out.println("vowels");
			break;
		case 'o':
			System.out.println("vowels");
			break;
		case 'u':
			System.out.println("vowels");
			break;
		case 'A':
			System.out.println("vowels");
			break;
		case 'E':
			System.out.println("vowels");
			break;
		case 'I':
			System.out.println("vowels");
			break;
		case 'O':
			System.out.println("vowels");
			break;
		case 'U':
			System.out.println("vowels");
			break;
	 default:
			System.out.println(" consonant");
			break;
		}
		}
	}
		