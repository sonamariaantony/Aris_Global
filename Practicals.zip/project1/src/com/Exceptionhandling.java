package com;
import java.io.FileReader;
import java.util.Scanner;
class NagtiveNumberNotAllowed extends Exception
{
	public NagtiveNumberNotAllowed(String message) {		
super(message);
		// TODO Auto-generated constructor stub
	}
	
}
public class Exceptionhandling {
public static void main(String[] args) throws NagtiveNumberNotAllowed  {
		// TODO Auto-generated method stu
	/*
		 * //FileReader file = new FileReader("C:\\test\\a.txt"); int c=10/0; Scanner
		 * sc=new Scanner(System.in); int a=sc.nextInt(); if(a>0) {
		 * System.out.println(a); } else {
		 * //System.out.println("nagtive Number not allowed"); throw new
		 * NagtiveNumberNotAllowed("Negtive Number not allowed"); }
		 */
	    String str=null;
	    System.out.println(str.charAt(0));
		
		
	}}