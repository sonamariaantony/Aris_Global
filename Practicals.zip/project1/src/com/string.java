package com;

public class string {

	public static void main(String args[]) {
		{
			String name="sona";
			String name1=new String("sona");
			name=name+"maria";
			StringBuffer sb=new StringBuffer(name);
			sb.append(" one 132");
			System.out.println(sb);
			}
	}}

