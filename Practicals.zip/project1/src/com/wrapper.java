package com;

public class wrapper {

	public static void main(String[] args) {
		String s="1888";
		int i=Integer.parseInt(s);
		System.out.println(i);
		double d=Double.parseDouble(s);
		System.out.println(d);
		float f=Float.parseFloat(s);
		System.out.println(f);

		}

		}