/*package com;

public class simple {

	public static void main(String[] args) {
		
String[] names = {"java","c","c++","python","javascript"};
System.out.println("printing the content of the array names:");
for(String name:names)
{
	System.out.println(name);
}
}}for (int i =0;i<=2;i++)	
	{
		for(int j=i;j<=5;j++)
		{
			if(j==4)
			{
				continue;
				System.out.println(j);
			}}}}*/
		

		
	
