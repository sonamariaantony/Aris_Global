package com;
/*class adder{
	static int add(int a,int b)
	{
		return a+b;}
	static int add(int a,int b,int c)
	{
	return a+b+c;}
		}*/
/*class overloading {
void sum(long a,long b)
	{
		System.out.println("this is int executed");
		System.out.println(a+b);
	}
	void sum(int a,int b,int c) {
		
		System.out.println(a+b+c);
	}
	public static void main(String[] args)
	{
		overloading obj=new overloading();
		obj.sum(11, 24);
		obj.sum(20,20,20);
	}}*/

	
